(function(){

    var page = {

       menuleft: $('#menu-left'),
       banner: $('#banner'),
       subBanner: $('#subBanner'),
       sales: $('#sales'),
       manupage1:$('#page1'),
       menupage2: $('#page2'),   
       menuCenter: $('#menuCenter'),    

       init: function(){

           var self = this;

           self.menuleft.hide();
           self.subBanner.hide();
           self.sales.hide();
           self.menupage2.hide();  
           self.loadEvents();        
       },

       loadEvents:function(){
            var self = this;
            $('a').click(function(){  
                self.menuCenter.hide();
                self.banner.hide();
                self.menuleft.show();
                self.subBanner.show();
                self.sales.show();
                self.manupage1.hide();
                self.menupage2.show();                
            });

            self.subBanner.click(function(){  
                self.menuCenter.show();
                self.banner.show();
                self.menuleft.hide();
                self.subBanner.hide();
                self.sales.hide();
                self.manupage1.show();
                self.menupage2.hide();               
            });
        }

    };
   
   page.init();
// $('#menu-left').hide();

})();